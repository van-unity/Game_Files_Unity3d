namespace Pools {
    public class SpawnableGameObject : SpawnableMonoBehaviour<SpawnableGameObject> {
    }
}